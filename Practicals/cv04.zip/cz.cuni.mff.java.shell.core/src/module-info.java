module cz.cuni.mff.java.shell.core {
    exports cz.cuni.mff.java.shell;
    uses cz.cuni.mff.java.shell.Command;
}