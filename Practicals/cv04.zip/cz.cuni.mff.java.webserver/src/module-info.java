module cz.cuni.mff.java.webserver {
    requires java.logging;
    requires java.scripting;
}